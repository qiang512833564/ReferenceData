//
//  XMSettingController.h
//  WSY_XMHelper
//
//  Created by 袁仕崇 on 15/1/2.
//  Copyright (c) 2015年 wilson-yuan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XMSettingController : UITableViewController

@end
