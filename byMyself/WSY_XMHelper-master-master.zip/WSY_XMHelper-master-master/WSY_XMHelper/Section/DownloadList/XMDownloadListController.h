//
//  XMDownloadListController.h
//  WSY_XMHelper
//
//  Created by 袁仕崇 on 14/12/10.
//  Copyright (c) 2014年 wilson-yuan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XMDownloadListController : UITableViewController

@end
