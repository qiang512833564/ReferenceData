//
//  XMDownloadInfo.m
//  WSY_XMHelper
//
//  Created by 袁仕崇 on 14/12/15.
//  Copyright (c) 2014年 wilson-yuan. All rights reserved.
//

#import "XMDownloadInfo.h"


@implementation XMDownloadInfo

@dynamic done;
@dynamic img;
@dynamic imgString;
@dynamic length;
@dynamic name;
@dynamic time;
@dynamic urlString;
@dynamic youku_id;
@dynamic start;
@dynamic addTime;
@dynamic filePath;

@end
