//
//  PersonView.h
//  rrmj个人主页
//
//  Created by lizhongqiang on 15/8/27.
//  Copyright (c) 2015年 lqq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PersonView : UIView
@property (nonatomic, strong)UIImageView *iconImageView;
@property (nonatomic, strong)UIImageView *iconStar;
@property (nonatomic, strong)UILabel *nameLabel;
@property (nonatomic, strong)UILabel *englishLabel;
@end
