//
//  SeriesViewController.h
//  rrmj个人主页
//
//  Created by lizhongqiang on 15/8/27.
//  Copyright (c) 2015年 lqq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SeriesViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end
