//
//  ShowScoreView.h
//  rrmj个人主页
//
//  Created by lizhongqiang on 15/8/28.
//  Copyright (c) 2015年 lqq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShowScoreView : UIView
+ (ShowScoreView *)sharedShowScoreView;
- (void)showScoreView;
@end
