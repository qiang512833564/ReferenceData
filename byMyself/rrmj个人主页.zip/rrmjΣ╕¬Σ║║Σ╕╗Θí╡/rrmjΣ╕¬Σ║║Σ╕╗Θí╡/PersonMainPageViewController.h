//
//  PersonMainPageViewController.h
//  rrmj个人主页
//
//  Created by lizhongqiang on 15/8/26.
//  Copyright (c) 2015年 lqq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PersonMainPageViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end
